</body>
<footer>
  <div class="footer container-fluid text-right">
    <em>&copy; 2016 - VariaBaru - @riespratama ITMS version 0.1.3</em>
  </div>
</footer>

</html>
